<?php

defined('_JEXEC') or die('Restricted access');


class plgJSPaymentsn extends JPlugin {
	var $params				= null;
	var $_name				= 'sn';
	var $_info				= null;
	var $live_site			= null;
	var $data				= array();
	var $_url				= null;
	var $_pin				= null;
	var $_ppnotify			= array(
								'valid_ip'			=> true,
								'order_stt'			=> '',
								'email_sbj'			=> '',
								'email_body'		=> ''
								);


	function __construct(& $subject, $params) {
		parent::__construct($subject, $params);
		
		$this->_name			= 'sn';
		$this->_url				= '';
		$this->live_site		= JUri::base();
		$this->_pin				= $this->params->get('sn_pin');
	}

	function onPaymentInfo() {
		if (empty($this->_info)) {
			$this->_info = array(
				'code'		=> 'sn',							
				'name'		=> JText::_('sn'),					
				'image'		=> $this->params->get('payment_image'),	
				'use_cc'	=> 0,								
			);
		}

		return $this->_info;
	}


	function onProcessPayment($order)
	{
		if ($order->payment_method != $this->_name)
		{
			return JOOMSELLER_PAYMENT_PROCESS_NO_CC;
		}
// Security
@session_start();
$sec = uniqid();
$md = md5($sec.'vm');
// Security

			$orderID  = rand(1,999999999);
			
			
$data_string = json_encode(array(
'pin'=> $this->_pin,
'price'=> $order->total_price,
'callback'=>  $order->notify_url.'&md='.$md.'&sec='.$sec ,
'order_id'=> $orderID, urlencode('Invoice ID : '.$orderID),
'ip'=> $_SERVER['REMOTE_ADDR'],
'callback_type'=>2
));

$ch = curl_init('https://developerapi.net/api/v1/request');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);


$json = json_decode($result,true);
if(!empty($json['result']) AND $json['result'] == 1)
{
				@session_start();
				// Set Session
$_SESSION[$sec] = [
	'price'=>$order->total_price ,
	'order_id'=>$orderID, urlencode('Invoice ID : '.$orderID) ,
	'au'=>$json['au'] ,
	'id'=> $order->id,
];
				echo '<div style="display:none">'.$json['form'].'</div>Please wait ... <script language="javascript">document.payment.submit(); </script>';
				echo '<p style="font:12px Tahoma; direction:rtl;text-align:center;color:#ff0000">در حال اتصال به درگاه ...</p>';
			}
			else
			{
				echo '<p style="font:12px Tahoma; direction:rtl;text-align:center;color:#ff0000">خطای غیر منتظره ('.$json['msg'].') !!!</p>';
			}



		return JOOMSELLER_PAYMENT_PROCESS_NO_CC;
	}


	function onPaymentNotify($payment_method) {		
		if ($payment_method != $this->_name) {
			return array();
		}

		@session_start();
		$transData = $_SESSION[$sec];
		$au=$transData['au']; //
	     $id      = $_SESSION['id'];   
		$orderID = $transData['order_id'];
		$amount  = $transData['price'];
		$data	= array(			
			'order_id'			=> $id,//$post['custom'],
			'transaction_id'	=> $au//$post['txn_id']
		);
		return $data;
	}


	function onVerifyPayment($order) {
		if ($order->payment_method != $this->_name)
		{
			return false;
		}
		if($this->validate_ipn($order))
		{
			return array('status'	=>	$this->_ppnotify['order_stt']);
		}
		return true;
	}
	

	function validate_ipn($order)
	{
		
		
// Security
@session_start();
$sec=$_GET['sec'];
$mdback = md5($sec.'vm');
$mdurl=$_GET['md'];
// Security

		
		
	
$transData = $_SESSION[$sec];
$au=$transData['au']; //
	     $id      = $_SESSION['id'];   
		$orderID = $transData['order_id'];
		$amount  = $transData['price'];

if(isset($_GET['sec']) or isset($_GET['md']) AND $mdback == $mdurl ){
// CallBack
$bank_return = $_POST + $_GET ;
$data_string = json_encode(array (
'pin' => $this->_api,
'price' => $amount,
'order_id' => $orderID,
'au' => $au,
'bank_return' =>$bank_return,
));

$ch = curl_init('https://developerapi.net/api/v1/verify');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);
$json = json_decode($result,true);

		if($json['result'] == 1)
		{
				$this->_ppnotify['order_stt']	= "COMPLETED";
				$mailsubject = "sn IPN txn on your site";
				$mailbody = "Hello,\n\n";
				$mailbody .= "a sn transaction for you has been made on your website!\n";
				$mailbody .= "-----------------------------------------------------------\n";
				$mailbody .= "Transaction ID: $trans_id\n";
				$mailbody .= "Order ID: ".$id."\n";
				$mailbody .= "Payment Status returned by sn: $json[result]\n";
				$mailbody .= "Order Status Code: ".$this->_ppnotify['order_stt'];
				$this->_ppnotify['email_sbj']	= $mailsubject;
				$this->_ppnotify['email_body']	= $mailbody;
				return true;
		}
		else
		{
			$this->_ppnotify['order_stt']	= "FALSE";
			$mailsubject = "sn IPN Transaction on your site";
			$mailbody = "Hello,
				 a Failed sn Transaction on " . $this->_live_site . " requires your attention.
				 -----------------------------------------------------------
				 Order ID: " . $id . "
				 User ID: " . $order->user_id . "
				 Payment Status returned by sn: $json[msg]
			
				$error_description";
			$this->_ppnotify['email_sbj']	= $mailsubject;
			$this->_ppnotify['email_body']	= $mailbody;
			return true;			
		}
				}
		else
		{
			$this->_ppnotify['order_stt']	= "FALSE";
			$mailsubject = "sn IPN Transaction on your site";
			$mailbody = "Hello,
				 a Failed sn Transaction on " . $this->_live_site . " requires your attention.
				 -----------------------------------------------------------
				 Order ID: " . $id . "
				 User ID: " . $order->user_id . "
				 Payment Status returned by sn: $json[msg]
			
				$error_description";
			$this->_ppnotify['email_sbj']	= $mailsubject;
			$this->_ppnotify['email_body']	= $mailbody;
			return true;			
		}
		return false;
	}
}